
package selflearning;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class DateManipulator {

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    public LocalDate stringToDate(String dateString) {
    	
    	return LocalDate.parse(dateString, FORMATTER);
    }
    
    public String dateToString(LocalDate date) {
    	
        return date.format(FORMATTER);
    }

    // Find number of days between two dates
    public long daysBetween(LocalDate start, LocalDate end) {
    	
        return ChronoUnit.DAYS.between(start, end);
    }

    public static void main(String[] args) {
        DateManipulator dm = new DateManipulator();

        // 1. String to Date
        String dateStr = "15-04-2026";
        LocalDate dateObj = dm.stringToDate(dateStr);
        System.out.println("LocalDate Object: " + dateObj);

        // 2. Date to String
        String convertedStr = dm.dateToString(dateObj);
        System.out.println("Formatted String: " + convertedStr);

        // 3. Days between two dates
        LocalDate date1 = LocalDate.of(2024, 4, 1);
        LocalDate date2 = LocalDate.of(2024, 4, 15);
        long days = dm.daysBetween(date1, date2);
        System.out.println("Days between " + date1 + " and " + date2 + ": " + days);
    }

}
