

package selflearning;

public class ThreadLocalDemo25 {
    public static void main(String[] args) throws InterruptedException {
        ThreadLocal<String> threadLocal = new ThreadLocal<>();

        Thread t1 = new Thread(() -> {
            threadLocal.set("Thread-1 Specific Data");
            try { Thread.sleep(500); } catch (InterruptedException e) {}
            System.out.println(Thread.currentThread().getName() + " sees: " + threadLocal.get());
        }, "Thread-1");

        Thread t2 = new Thread(() -> {
            threadLocal.set("Thread-2 Specific Data");
            try { Thread.sleep(500); } catch (InterruptedException e) {}
            System.out.println(Thread.currentThread().getName() + " sees: " + threadLocal.get());
        }, "Thread-2");

        t1.start();
        t2.start();
        
        t1.join();
        t2.join();
    }
}