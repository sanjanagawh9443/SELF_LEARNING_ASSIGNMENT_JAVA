

package selflearning;
import java.util.*;

public class QueueLinkedListApp {
    public static void main(String[] args) {
     
        Queue<String> queue = new LinkedList<>();

        // Enqueue: Adding elements to the rear
        queue.add("Alice");
        queue.offer("Bob");
        queue.add("Charlie");

        System.out.println("Initial Queue: " + queue);

        // Peek: View the front element without removing it
        System.out.println("Front element (peek): " + queue.peek());

        // Dequeue: Remove and return the front element
        String removedElement = queue.poll();
        System.out.println("Removed element (poll): " + removedElement);

        System.out.println("Queue after removal: " + queue);

        // 2. Iterating through the Queue
        System.out.println("Iterating through remaining elements:");
        for (String name : queue) {
            System.out.println("- " + name);
        }

        // Check if queue is empty
        System.out.println("Is queue empty? " + queue.isEmpty());
        
        // Clear the queue
        queue.clear();
        System.out.println("Queue size after clear: " + queue.size());
    }
}