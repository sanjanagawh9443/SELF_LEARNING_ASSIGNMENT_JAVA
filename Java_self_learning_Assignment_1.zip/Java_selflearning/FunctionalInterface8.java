
package selflearning;

@FunctionalInterface
interface Calculator {
    int operate(int a, int b);
}

public class FunctionalInterface8 {
    public static void main(String[] args) {
        
        // 1. Using Anonymous Class
        Calculator addition = new Calculator() {
            @Override
            public int operate(int a, int b) {
                return a + b;
            }
        };

        // 2. Using Lambda Expression
        Calculator multiplication = (a, b) -> a * b;

        System.out.println("Addition (Anonymous Class): " + addition.operate(20, 10));
        System.out.println("Multiplication (Lambda): " + multiplication.operate(20, 10));
    }
}