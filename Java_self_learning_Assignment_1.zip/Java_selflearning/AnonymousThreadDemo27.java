

package selflearning;

public class AnonymousThreadDemo27 {
    public static void main(String[] args) {

        Thread t1 = new Thread() {
            @Override
            public void run() {
                System.out.println("Thread 1 (Extending Thread class) is running.");
            }
        };

        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Thread 2 (Implementing Runnable interface) is running.");
            }
        });

        t1.start();
        t2.start();
    }
}