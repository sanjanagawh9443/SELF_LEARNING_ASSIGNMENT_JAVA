package selflearning;

public class BoxingUnboxingDemo {
	
	public static void main(String[] args) {
		System.out.println("---Java Boxing & Unboxing Assignment---");
		
		int primitiveInt = 25;
		
		Integer boxedInt = primitiveInt;
		
		Integer manualBoxed = Integer.valueOf(primitiveInt);
		
		System.out.println("primitive value: "+ primitiveInt);
		System.out.println("Boxed Integer object: "+ boxedInt);
		
		int unboxedInt = boxedInt;
		int manualUnboxed = boxedInt.intValue();
				
		System.out.println("Unboxed primitive value: " + unboxedInt);
		
		java.util.ArrayList<Double> list = new java.util.ArrayList<>();
		
		list.add(99.9);
		
		double valueFromList = list.get(0);
		
		System.out.println("value from ArrayList (unboxed): " + valueFromList);
			 
		
	}

}
