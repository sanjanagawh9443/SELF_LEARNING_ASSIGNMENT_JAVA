
package selflearning; 

public class StringDemo {

    public static void main(String[] args) {
        // 1. Initial string with extra spaces
        String text = "  Java Programming is Fun!  ";
        System.out.println("Original: [" + text + "]");

        // 2. Create the 'trimmedText' variable (Fixes your first error)
        String trimmedText = text.trim();
        System.out.println("After Trim: [" + trimmedText + "]");

        // 3. Perform manipulations using the 'trimmedText' variable
        System.out.println("Length: " + trimmedText.length());
        System.out.println("Uppercase: " + trimmedText.toUpperCase());
        System.out.println("Contains 'Java'?: " + trimmedText.contains("Java"));
        System.out.println("Index of 'P': " + trimmedText.indexOf("P"));

        // 4. Create the 'replacedText' variable (Fixes your second error)
        String replacedText = trimmedText.replace("Fun", "Awesome");
        System.out.println("Replaced String: " + replacedText);

        // 5. Substring example
        String sub = trimmedText.substring(0, 4);
        System.out.println("Extracted Word: " + sub);
    }
}
