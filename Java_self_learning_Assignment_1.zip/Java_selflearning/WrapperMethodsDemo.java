package selflearning;

public class WrapperMethodsDemo {
	public static void main(String[]args) {
		System.out.println("--- Java Wrapper Class Methods Demonstration ---");
	
		String scoreStr = "150";
		int score = Integer.parseInt(scoreStr);
		Integer scoreObj = Integer.valueOf(score);
		
		System.out.println("Max of 10 and 20: " + Integer.max(10,20));
		System.out.println("Binary of 150: " + Integer.toBinaryString(150));
		System.out.println("Hex of 150: " + Integer.toHexString(150));
		
		Double priceObj = 199.99;
		System.out.println("Is price Nan? "+ Double.isNaN(priceObj));
		System.out.println("Comparing 10.5 and 20.5: " + Double.compare(10.5, 20.5));
		
		char letter = 'A';
		char digit = '5';
		System.out.println("Is 'A' a letter? " + Character.isLetter(letter));
		System.out.println("Is '5' a digit? " + Character.isDigit(digit));
		System.out.println("Lowercase of 'A': " + Character.toLowerCase(letter));
		
		String status = "True";
		boolean isActive = Boolean.parseBoolean(status);
		System.out.println("Boolean Status: " + isActive);
		
		Integer age =23;
		double ageDouble = age.doubleValue();
		byte ageAsByte = age.byteValue();
		System.out.println("Integer 23 as double: " + ageDouble);
		
	}
	

}
