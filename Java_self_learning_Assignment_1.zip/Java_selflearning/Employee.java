package selflearning;

public class Employee {
	
	private int id;
	private String name;
	private double salary;
	
	public 	Employee (int id, String name, double salary) {
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public double getSalary() {
		return salary;
}
	public void setSalary(double salary) {
		if (salary > 0 ) {
			this.salary = salary;
		} else {
			System.out.println("Error: Salary must be positive value!");
			
		}
	}
	public void display() {
		System.out.println("ID : " + id + ", Name: " + name + ", Salary: " + salary);
	}
	public static void main(String[] args) {
		Employee emp = new Employee(101,"Sanjana", 50000);
		
		System.out.println("Fetching Name: " + emp.getName());
		
		System.out.println("Updating Salary...");
		emp.setSalary(550000.0);
		
		System.out.println("\n---Final Employee Details ---");
		emp.display();
	}
}

	
	
	
	
	
	
	


