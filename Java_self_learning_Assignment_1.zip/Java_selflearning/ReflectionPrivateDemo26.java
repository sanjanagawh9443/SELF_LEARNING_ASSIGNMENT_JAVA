

package selflearning;

import java.lang.reflect.Method;

class SecretClass {
    private void secretMethod(String message) {
        System.out.println("Message from private method: " + message);
    }
}

public class ReflectionPrivateDemo26 {
    public static void main(String[] args) throws Exception {
        SecretClass obj = new SecretClass();
        
        Method method = SecretClass.class.getDeclaredMethod("secretMethod", String.class);
        
        method.setAccessible(true);
        
        method.invoke(obj, "Hello Reflection!");
    }
}