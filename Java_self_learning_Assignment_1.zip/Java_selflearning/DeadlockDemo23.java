
package selflearning;

public class DeadlockDemo23 {
    public static void main(String[] args) {
        final Object resource1 = "Resource A";
        final Object resource2 = "Resource B";

        
        Thread t1 = new Thread(() -> {
            synchronized (resource1) {
                System.out.println("Thread 1: Locked Resource A");

                try { Thread.sleep(100); } catch (InterruptedException e) {}

                synchronized (resource2) {
                    System.out.println("Thread 1: Locked Resource B");
                }
            }
        });

        
        Thread t2 = new Thread(() -> {
            synchronized (resource2) {
                System.out.println("Thread 2: Locked Resource B");

                try { Thread.sleep(100); } catch (InterruptedException e) {}

                synchronized (resource1) {
                    System.out.println("Thread 2: Locked Resource A");
                }
            }
        });

        t1.start();
        t2.start();
    }
}