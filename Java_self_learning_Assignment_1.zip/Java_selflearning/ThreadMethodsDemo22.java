

package selflearning;

class MyThread extends Thread {
    public MyThread(String name) {
        super(name);
    }

    @Override
    public void run() {
        for (int i = 1; i <= 3; i++) {
            System.out.println(Thread.currentThread().getName() + " executing step " + i);
            
            if (i == 1) {
                System.out.println(Thread.currentThread().getName() + " yielding...");
                Thread.yield();
            }

            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }
}

public class ThreadMethodsDemo22 {
    public static void main(String[] args) throws InterruptedException {
        MyThread t1 = new MyThread("Thread-1");
        MyThread t2 = new MyThread("Thread-2");

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println("Main thread ends after Thread-1 and Thread-2 finished (Join successful).");
    }
}