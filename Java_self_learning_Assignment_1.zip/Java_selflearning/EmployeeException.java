

package selflearning;

// User-defined Checked Exception (Extends Exception)
class AgeNotValidException extends Exception {
    public AgeNotValidException(String message) {
        super(message);
    }
}

// User-defined Unchecked Exception (Extends RuntimeException)
class NegativeSalaryException extends RuntimeException {
    public NegativeSalaryException(String message) {
        super(message);
    }
}

public class EmployeeException {

    // Method using a Checked Exception (must declare 'throws')
    public static void checkAge(int age) throws AgeNotValidException {
        if (age < 18) {
            throw new AgeNotValidException("Age must be 18 or older to register.");
        }
        System.out.println("Registration successful for age: " + age);
    }

    // Method using an Unchecked Exception (no 'throws' required)
    public static void checkSalary(double salary) {
        if (salary < 0) {
            throw new NegativeSalaryException("Salary cannot be a negative value.");
        }
        System.out.println("Salary updated to: " + salary);
    }

    public static void main(String[] args) {
        // Handling Checked Exception
        try {
            checkAge(16);
        } catch (AgeNotValidException e) {
            System.out.println("Caught Checked Exception: " + e.getMessage());
        }

        // Handling Unchecked Exception
        try {
            checkSalary(-1500.0);
        } catch (NegativeSalaryException e) {
            System.out.println("Caught Unchecked Exception: " + e.getMessage());
        }
    }
}