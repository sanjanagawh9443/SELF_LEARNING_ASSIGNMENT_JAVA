

package selflearning;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class DateManipulator9 {

    public static void main(String[] args) {
        String dateStr = "2026-04-13";
        
        // 1. String to Date
        LocalDate date = stringToDate(dateStr);
        System.out.println("Converted String to Date: " + date);

        // 2. Date to String
        String formattedDate = dateToString(date);
        System.out.println("Converted Date to String (dd/MM/yyyy): " + formattedDate);

        // 3. Days between two dates
        LocalDate futureDate = LocalDate.of(2026, 12, 31);
        long daysBetween = getDaysBetween(date, futureDate);
        System.out.println("Days between " + date + " and " + futureDate + ": " + daysBetween);
    }

    public static LocalDate stringToDate(String dateString) {
        return LocalDate.parse(dateString); // Expects yyyy-MM-dd format
    }

    public static String dateToString(LocalDate date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return date.format(formatter);
    }

    public static long getDaysBetween(LocalDate start, LocalDate end) {
        return ChronoUnit.DAYS.between(start, end);
    }
}