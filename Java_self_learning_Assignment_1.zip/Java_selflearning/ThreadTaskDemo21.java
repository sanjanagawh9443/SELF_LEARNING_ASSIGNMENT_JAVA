

package selflearning;

class SameTask implements Runnable {
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " is performing the SAME task.");
    }
}

class TaskOne implements Runnable {
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " is performing Task ONE.");
    }
}

class TaskTwo implements Runnable {
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " is performing Task TWO.");
    }
}

public class ThreadTaskDemo21 {
    public static void main(String[] args) {
        SameTask commonTask = new SameTask();
        Thread t1 = new Thread(commonTask, "Thread-1");
        Thread t2 = new Thread(commonTask, "Thread-2");

        Thread t3 = new Thread(new TaskOne(), "Thread-3");
        Thread t4 = new Thread(new TaskTwo(), "Thread-4");

        t1.start();
        t2.start();
        t3.start();
        t4.start();
    }
}