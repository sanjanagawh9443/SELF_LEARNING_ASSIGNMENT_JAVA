

package selflearning;

import java.util.*;

class EmployeeModel implements Comparable<EmployeeModel> {
    private int id;
    private String name;
    private double salary;

    public EmployeeModel(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public double getSalary() { return salary; }

    @Override
    public int compareTo(EmployeeModel other) {
        return Integer.compare(this.id, other.id);
    }

    @Override
    public String toString() {
        return "[ID=" + id + ", Name=" + name + ", Salary=" + salary + "]";
    }
}

class NameComparator implements Comparator<EmployeeModel> {
    @Override
    public int compare(EmployeeModel e1, EmployeeModel e2) {
        return e1.getName().compareTo(e2.getName());
    }
}

public class EmployeeModel11{
    public static void main(String[] args) {
        List<EmployeeModel> employees = new ArrayList<>();
        employees.add(new EmployeeModel(103, "Charlie", 50000));
        employees.add(new EmployeeModel(101, "Alice", 70000));
        employees.add(new EmployeeModel(102, "Bob", 60000));

        Collections.sort(employees);
        System.out.println("Sorted by ID (Comparable): " + employees);

        Collections.sort(employees, new NameComparator());
        System.out.println("Sorted by Name (Comparator): " + employees);
    }
}
