

package selflearning;

class TaskThread extends Thread {
    @Override
    public void run() {
        for (int i = 1; i <= 3; i++) {
            System.out.println(Thread.currentThread().getName() + " (Thread Class) - Count: " + i);
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    }
}

class TaskRunnable implements Runnable {
    @Override
    public void run() {
        for (int i = 1; i <= 3; i++) {
            System.out.println(Thread.currentThread().getName() + " (Runnable Interface) - Count: " + i);
            try { Thread.sleep(500); } catch (InterruptedException e) {}
        }
    }
}

public class MultiThreadingDemo20 {
    public static void main(String[] args) {
        TaskThread thread1 = new TaskThread();
        thread1.setName("Thread-A");

        Thread thread2 = new Thread(new TaskRunnable());
        thread2.setName("Thread-B");

        thread1.start();
        thread2.start();
    }
}