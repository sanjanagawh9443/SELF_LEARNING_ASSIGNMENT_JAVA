
package selflearning;

//1. SINGLE INHERITANCE: One class extends one class
class Animal {
 void eat() {
     System.out.println("Animal is eating...");
 }
}

class Dog extends Animal {
 void bark() {
     System.out.println("Dog is barking...");
 }
}

//2. MULTILEVEL INHERITANCE: A chain of inheritance
class Puppy extends Dog {
 void play() {
     System.out.println("Puppy is playing...");
 }
}

//3. HIERARCHICAL INHERITANCE: Multiple classes inherit from one parent
class Cat extends Animal {
 void meow() {
     System.out.println("Cat is meowing...");
 }
}

//4. MULTIPLE INHERITANCE (via Interfaces)
interface Swimmer {
 void swim();
}

interface Runner {
 void run();
}

class Frog implements Swimmer, Runner {
 public void swim() {
     System.out.println("Frog is swimming.");
 }
 public void run() {
     System.out.println("Frog is hopping/running.");
 }
}

//5. HYBRID INHERITANCE (Combination of types)
class FlyingFrog extends Frog {
 void glide() {
     System.out.println("Flying Frog is gliding through the air.");
 }
}

//MAIN CLASS
public class Inheritance7 {
 public static void main(String[] args) {
     
     System.out.println("--- Single Inheritance ---");
     Dog myDog = new Dog();
     myDog.eat(); // From Animal
     myDog.bark(); // From Dog

     System.out.println("\n--- Multilevel Inheritance ---");
     Puppy myPuppy = new Puppy();
     myPuppy.eat(); // From Animal
     myPuppy.bark(); // From Dog
     myPuppy.play(); // From Puppy

     System.out.println("\n--- Hierarchical Inheritance ---");
     Cat myCat = new Cat();
     myCat.eat(); // From Animal (Shared with Dog/Puppy)
     myCat.meow(); // From Cat

     System.out.println("\n--- Multiple Inheritance (Interfaces) ---");
     Frog myFrog = new Frog();
     myFrog.swim();
     myFrog.run();

     System.out.println("\n--- Hybrid Inheritance ---");
     FlyingFrog ff = new FlyingFrog();
     ff.swim(); // From Frog (Multiple part)
     ff.glide(); // From FlyingFrog (Single/Hierarchical part)
 }
}
