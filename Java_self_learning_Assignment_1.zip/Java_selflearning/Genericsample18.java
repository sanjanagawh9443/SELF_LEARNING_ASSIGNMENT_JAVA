
package selflearning;

import java.util.*;

class AnimalG {
    String name = "Animal";
}

class DogG extends AnimalG {
    String name = "Dog";
}

class PuppyG extends DogG {
    String name = "Puppy";
}

public class Genericsample18 {

    public static void displayAny(List<?> list) {
        for (Object obj : list) {
            System.out.print(obj.getClass().getSimpleName() + " ");
        }
        System.out.println();
    }

    public static void processExtends(List<? extends DogG> list) {
        for (DogG d : list) {
            System.out.print(d.name + " ");
        }
        System.out.println();
    }

    public static void processSuper(List<? super DogG> list) {
        for (Object obj : list) {
            System.out.print(obj.getClass().getSimpleName() + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        List<AnimalG> animals = Arrays.asList(new AnimalG());
        List<DogG> dogs = Arrays.asList(new DogG());
        List<PuppyG> puppies = Arrays.asList(new PuppyG());

        System.out.print("Unbounded (?): ");
        displayAny(animals);

        System.out.print("Upper Bound (? extends DogG): ");
        processExtends(puppies);

        System.out.print("Lower Bound (? super DogG): ");
        processSuper(animals);
    }
}
