
package selflearning;

public class LambdaThreadDemo28 {
    public static void main(String[] args) {
        Thread t1 = new Thread(() -> {
            System.out.println("Thread 1 is running via Lambda.");
        });

        Thread t2 = new Thread(() -> {
            for (int i = 1; i <= 3; i++) {
                System.out.println("Thread 2 counting: " + i);
            }
        });

        t1.start();
        t2.start();
    }
}