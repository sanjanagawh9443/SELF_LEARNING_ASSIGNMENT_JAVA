

package selflearning;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class WrapperCollection10 {
    public static void main(String[] args) {
        // List of Integer Wrapper Class
        List<Integer> numbers = new ArrayList<>();

        // 1. INSERT (Add elements)
        numbers.add(50);
        numbers.add(10);
        numbers.add(30);
        numbers.add(20);
        numbers.add(40);
        System.out.println("Original List: " + numbers);

        // 2. DELETE (Remove by index or value)
        numbers.remove(Integer.valueOf(30)); // Removes the object '30'
        System.out.println("After Deleting 30: " + numbers);

        // 3. SEARCH (Check if exists)
        if (numbers.contains(20)) {
            System.out.println("Search: 20 is present at index " + numbers.indexOf(20));
        }

        // 4. SORT (Ascending order)
        Collections.sort(numbers);
        System.out.println("Sorted List: " + numbers);

        // 5. ITERATE (Using Iterator)
        System.out.print("Iterating through list: ");
        Iterator<Integer> it = numbers.iterator();
        while (it.hasNext()) {
            System.out.print(it.next() + " ");
        }
        System.out.println();
    }
}