

package selflearning;

public class LibrarySystem6 {

    static abstract class LibraryItem6 {
        private String id;
        
        public LibraryItem6(String id) {
            this.id = id;
        }
        
        public String getId() {
            return id;    
        }
        
        public abstract void displayInfo();
    }
    
    static class Book extends LibraryItem6 {
        private String title;
        private String author;
        
        public Book(String id, String title, String author) {
            super(id);
            this.title = title;
            this.author = author;
        }
        
        @Override
        public void displayInfo() {
            System.out.println("Book [ID: " + getId() + "] Title: " + title + ", Author: " + author);    
        }
        
        public void displayInfo(String user) {
            System.out.println(user + " is viewing: " + title);
        }
    }

    static class Magazine extends LibraryItem6 {
        private int issueNumber;
        
        public Magazine(String id, int issueNumber) {
            super(id);
            this.issueNumber = issueNumber;
        }

        @Override
        public void displayInfo() {
             System.out.println("Magazine [ID: " + getId() + "] Issue: " + issueNumber);
        }    
    }

    public static void main(String[] args) {
        LibraryItem6[] items = new LibraryItem6[2];
        
        items[0] = new Book("B001", "Java Programming", "James Gosling");
        items[1] = new Magazine("M102", 45);
        
        System.out.println("--- Library Inventory ---");
        
        for (LibraryItem6 item : items) {
            item.displayInfo();
        }

        System.out.println("\n--- Method Overloading ---");
        Book myBook = (Book) items[0];
        myBook.displayInfo("Student_John");
    }
}