
package selflearning;

import java.util.HashSet;
import java.util.Objects;

class EmployeeUniquee {
    int id;
    String name;

    public EmployeeUniquee(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        EmployeeUniquee other = (EmployeeUniquee) obj;
        return id == other.id;
    }

    @Override
    public String toString() {
        return "Employee[ID=" + id + ", Name=" + name + "]";
    }
}

public class Employeedemo17 {
    public static void main(String[] args) {
        HashSet<EmployeeUniquee> employeeSet = new HashSet<>();

        employeeSet.add(new EmployeeUniquee(101, "Alice"));
        employeeSet.add(new EmployeeUniquee(101, "Duplicate Alice"));
        employeeSet.add(new EmployeeUniquee(102, "Bob"));

        System.out.println("Total unique employees: " + employeeSet.size());
        
        for (EmployeeUniquee emp : employeeSet) {
            System.out.println(emp);
        }
    }
}