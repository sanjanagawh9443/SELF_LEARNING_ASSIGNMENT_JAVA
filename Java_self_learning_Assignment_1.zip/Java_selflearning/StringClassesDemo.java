
package selflearning;

public class StringClassesDemo {
    public static void main(String[] args) {
        
        // 1. String - Immutable (Cannot be changed)
        String s = "Hello";
        s.concat(" World"); // This creates a NEW object, but 's' remains "Hello"
        System.out.println("String Result: " + s); 

        // 2. StringBuffer - Mutable and Thread-Safe (Synchronized)
        StringBuffer sbf = new StringBuffer("Hello");
        sbf.append(" World"); // Modifies the original object
        System.out.println("StringBuffer Result: " + sbf);

        // 3. StringBuilder - Mutable and Fast (Not Synchronized)
        StringBuilder sbd = new StringBuilder("Hello");
        sbd.append(" World"); // Modifies the original object
        System.out.println("StringBuilder Result: " + sbd);
    }
}
