
package selflearning;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class WrapperOperations14 {
	public static void main(String[] args) {
      
        List<Integer> numberList = new ArrayList<>();
    
        numberList.add(50);
        numberList.add(10);
        numberList.add(30);
        numberList.add(20);
        numberList.add(40);
        
        System.out.println("Original List: " + numberList);

        // --- Insert Operation ---
        numberList.add(2, 25); // Insert 25 at index 2
        System.out.println("After Insertion: " + numberList);

        // --- Search Operation ---
        int searchElement = 30;
        if (numberList.contains(searchElement)) {
            System.out.println("Element " + searchElement + " found at index: " + numberList.indexOf(searchElement));
        } else {
            System.out.println("Element " + searchElement + " not found.");
        }

        // --- Delete Operation ---
        numberList.remove(Integer.valueOf(25)); // Remove by object value
        numberList.remove(0); // Remove by index
        System.out.println("After Deletion: " + numberList);

        // --- Sort Operation ---
        Collections.sort(numberList);
        System.out.println("Sorted List: " + numberList);

        // --- Iterate Operation ---
        System.out.print("Iterating using for-each: ");
        for (Integer num : numberList) {
            System.out.print(num + " ");
        }
        System.out.println();

        // --- Iterator Usage ---
        System.out.print("Iterating using Iterator: ");
        Iterator<Integer> it = numberList.iterator();
        while (it.hasNext()) {
            System.out.print(it.next() + " ");
        }
        System.out.println();
    }
}
