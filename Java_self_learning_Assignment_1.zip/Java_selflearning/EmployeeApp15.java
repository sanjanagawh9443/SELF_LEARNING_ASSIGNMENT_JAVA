
package selflearning;
import java.util.*;

public class EmployeeApp15 {

    // 1. Employee class must be STATIC to be used in main
    static class Employee implements Comparable<Employee> {
        int id;
        String name;

        Employee(int id, String name) {
            this.id = id;
            this.name = name;
        }

        // 2. You MUST implement this method to satisfy Comparable
        @Override
        public int compareTo(Employee other) {
            return this.id - other.id; // Sorts by ID ascending
        }

        @Override
        public String toString() {
            return "ID: " + id + ", Name: " + name;
        }
    }

    // 3. Comparator for Name sorting
    static class NameComparator implements Comparator<Employee> {
        @Override
        public int compare(Employee e1, Employee e2) {
            return e1.name.compareTo(e2.name);
        }
    }

    public static void main(String[] args) {
        List<Employee> list = new ArrayList<>();
        list.add(new Employee(102, "Zack"));
        list.add(new Employee(101, "Alice"));

        // Sort using Comparable (by ID)
        Collections.sort(list);
        System.out.println("Sorted by ID: " + list);

        // Sort using Comparator (by Name)
        Collections.sort(list, new NameComparator());
        System.out.println("Sorted by Name: " + list);
    }
}