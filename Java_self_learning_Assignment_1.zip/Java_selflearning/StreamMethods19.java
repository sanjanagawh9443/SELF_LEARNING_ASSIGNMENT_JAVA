
package selflearning;

import java.util.*;
import java.util.stream.*;

public class StreamMethods19 {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(5, 2, 8, 1, 9, 2);

        long count = numbers.stream()
                            .count();
        System.out.println("Count: " + count);

        List<Integer> sortedList = numbers.stream()
                                          .sorted()
                                          .collect(Collectors.toList());
        System.out.println("Sorted: " + sortedList);

        List<Integer> distinctSquared = numbers.stream()
                                               .distinct()
                                               .map(n -> n * n)
                                               .collect(Collectors.toList());
        System.out.println("Mapped (Unique Squares): " + distinctSquared);

        int sum = numbers.stream()
                         .reduce(0, (a, b) -> a + b);
        System.out.println("Reduced (Sum): " + sum);

        List<Integer> filtered = numbers.stream()
                                        .filter(n -> n > 5)
                                        .collect(Collectors.toList());
        System.out.println("Filtered (Greater than 5): " + filtered);
    }
}